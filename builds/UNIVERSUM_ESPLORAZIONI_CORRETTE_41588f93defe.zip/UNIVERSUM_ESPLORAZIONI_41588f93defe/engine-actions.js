/**
 * UNIVERSUM — Engine Actions (Costruzioni, Ricerche, Flotte/Difese, Cheat & Autosave)
 */
(function () {
  'use strict';

  const TURBO_DURATION_MS = 15 * 60 * 1000; // 15 minuti di Turbo 2x
  const Engine = window.UniversumEngine;
  if (!Engine) return;

  const { getData, normalizePlanet } = Engine._internal;

  function canAfford(resources, cost) {
    return (
      resources.metal >= cost.metal &&
      resources.crystal >= cost.crystal &&
      resources.deuterium >= cost.deuterium
    );
  }

  function deductResources(resources, cost) {
    resources.metal = Math.max(0, resources.metal - cost.metal);
    resources.crystal = Math.max(0, resources.crystal - cost.crystal);
    resources.deuterium = Math.max(0, resources.deuterium - cost.deuterium);
  }

  // =========================================================
  // COSTRUZIONI PLANETARIE E LUNARI
  // =========================================================
  function startBuilding(universe, planetIndex, buildingId, isMoon = false, now = Date.now()) {
    const Data = getData();
    const planet = universe.planets[planetIndex];
    if (!planet) throw new Error('Pianeta non trovato.');
    normalizePlanet(planet);

    if (isMoon) {
      if (!planet.moon) throw new Error('Questo pianeta non possiede una Luna.');
      const def = Data.MOON_BUILDINGS[buildingId];
      if (!def) throw new Error('Edificio lunare sconosciuto.');

      const curLv = Number(planet.moon.buildings[buildingId] || 0);
      if (def.maxLevel && curLv >= def.maxLevel) {
        throw new Error(`${def.name} è già al livello massimo (${def.maxLevel}).`);
      }

      if (!universe.creativeMode) {
        if (planet.moon.buildQueue.length > 0) {
          throw new Error('Coda costruzioni lunari già occupata.');
        }
        if (buildingId !== 'lunarBase' && Data.getMoonUsedFields(planet.moon) >= Data.getMoonMaxFields(planet.moon)) {
          throw new Error('Campi lunari esauriti! Amplia la Base Lunare.');
        }
        const reqCheck = Data.checkRequirements(def.requirements, planet, universe, true);
        if (!reqCheck.met) {
          throw new Error(`Requisiti mancanti: ${reqCheck.missing.join(', ')}`);
        }
      }

      const targetLv = curLv + 1;
      if (universe.creativeMode) {
        planet.moon.buildings[buildingId] = targetLv;
        return { instant: true, targetLevel: targetLv };
      }

      const cost = Data.getBuildingCost(buildingId, targetLv, true);
      if (!canAfford(planet.resources, cost)) {
        throw new Error('Risorse insufficienti sul pianeta di supporto per la struttura lunare.');
      }

      deductResources(planet.resources, cost);
      const durationSec = Engine.getBuildingBuildTime(universe, planet, buildingId, targetLv, true, now);
      planet.moon.buildQueue.push({
      workId: window.UniversumServices?.uid() || 'job-' + now,
        id: buildingId,
        targetLevel: targetLv,
        startTime: now,
        endTime: now + durationSec * 1000,
        durationSec
      });
      return { instant: false, targetLevel: targetLv, durationSec };
    }

    // Edificio Planetario
    const def = Data.BUILDINGS[buildingId];
    if (!def) throw new Error('Edificio sconosciuto.');

    const curLv = Number(planet.buildings[buildingId] || 0);
    if (def.maxLevel && curLv >= def.maxLevel) {
      throw new Error(`${def.name} ha raggiunto il livello massimo (${def.maxLevel}).`);
    }

    if (!universe.creativeMode) {
      if (planet.buildQueue.length > 0) {
        throw new Error('Coda di costruzione già occupata su questo pianeta.');
      }
      if (buildingId !== 'terraformer' && Data.getUsedFields(planet) >= Data.getMaxFields(planet)) {
        throw new Error('Nessun campo libero sul pianeta! Costruisci un Terraformer.');
      }
      const reqCheck = Data.checkRequirements(def.requirements, planet, universe, false);
      if (!reqCheck.met) {
        throw new Error(`Requisiti mancanti: ${reqCheck.missing.join(', ')}`);
      }
      // Blocco energia: il livello successivo non deve portare il saldo in negativo
      const prodNow = Engine.getPlanetProduction(planet, universe);
      const techLv = Number(universe.researches?.energyTech || 0);
      const energyDelta = Data.getBuildingEnergyDelta(buildingId, curLv + 1, planet.maxTemp, techLv) - Data.getBuildingEnergyDelta(buildingId, curLv, planet.maxTemp, techLv);
      if (energyDelta < 0 && (prodNow.energyBalance + energyDelta) < 0) {
        throw new Error('Energia insufficiente');
      }
    }

    const targetLv = curLv + 1;
    if (universe.creativeMode) {
      planet.buildings[buildingId] = targetLv;
      if (buildingId === 'deuteriumSynth') planet.buildings.deuteriumSynthesizer = targetLv;
      return { instant: true, targetLevel: targetLv };
    }

    const cost = Data.getBuildingCost(buildingId, targetLv, false);
    if (!canAfford(planet.resources, cost)) {
      throw new Error('Risorse insufficienti per avviare la costruzione.');
    }

    deductResources(planet.resources, cost);
    const durationSec = Engine.getBuildingBuildTime(universe, planet, buildingId, targetLv, false, now);
    planet.buildQueue.push({
      workId: window.UniversumServices?.uid() || 'job-' + now,
      id: buildingId,
      targetLevel: targetLv,
      startTime: now,
      endTime: now + durationSec * 1000,
      durationSec
    });

    return { instant: false, targetLevel: targetLv, durationSec };
  }

  // =========================================================
  // RICERCHE & CANTIERE NAVALE / DIFESE
  // =========================================================
  function startResearch(universe, researchId, planetIndex = 0, now = Date.now()) {
    const Data = getData();
    const def = Data.RESEARCHES[researchId];
    if (!def) throw new Error('Ricerca sconosciuta.');
    const planet = universe.planets?.[planetIndex];
    if (!planet) throw new Error('Pianeta non trovato.');
    normalizePlanet(planet);
    Engine.normalizeResearchState(universe);
    const local = def.scope === 'planetary';
    Engine.advanceResearchQueues(universe, now);
    const current = Data.getResearchLevel(universe, planet, researchId);
    if (def.maxLevel && current >= def.maxLevel) throw new Error(`${def.name}: livello massimo ${def.maxLevel} raggiunto.`);
    const targetLevel = current + 1;
    if (!universe.creativeMode) {
      if (local ? planet.localResearchQueue : universe.researchQueue) {
        throw new Error(local ? 'Laboratorio locale già occupato su questo pianeta.' : 'Una ricerca imperiale è già in corso.');
      }
      const req = Data.checkRequirements(def.requirements, planet, universe, false);
      if (!req.met) throw new Error(`Requisiti mancanti: ${req.missing.join(', ')}`);
      if (Number(planet.buildings?.researchLab || 0) <= 0) throw new Error('Serve un Laboratorio di Ricerca attivo.');
      if (!local && Engine.getTotalLabLevel(universe, now) <= 0) throw new Error('Non ci sono laboratori liberi per la ricerca imperiale.');
    }
    if (universe.creativeMode) {
      const into = local ? planet.localResearches : universe.researches;
      into[researchId] = targetLevel;
      return { instant: true, targetLevel, planetId: local ? planet.id : null };
    }
    const cost = Data.getResearchCost(researchId, targetLevel);
    if (!canAfford(planet.resources, cost)) throw new Error('Risorse insufficienti sul pianeta attivo per questa ricerca.');
    const durationSec = Engine.getResearchTime(universe, researchId, targetLevel, planet, now);
    if (!Number.isFinite(durationSec) || durationSec < 1) throw new Error('Impossibile calcolare il tempo di ricerca.');
    deductResources(planet.resources, cost);
    const queue = { id: researchId,
      workId: window.UniversumServices?.uid() || 'job-' + now, targetLevel, planetId: planet.id, startTime: now,
      endTime: now + durationSec * 1000, durationSec,
      ownerUid: local ? (planet.ownerUid || null) : null };
    if (local) {
      planet.localResearchQueue = queue;
      Engine.refreshImperialETA(universe, now);
    } else {
      // Work is tracked in laboratory-seconds, preventing retroactive speed changes.
      queue.workTotal = Math.max(1, (cost.metal + cost.crystal) * 3.6);
      queue.workDone = 0;
      queue.lastProgressAt = now;
      universe.researchQueue = queue;
      Engine.refreshImperialETA(universe, now);
    }
    return { instant: false, targetLevel, durationSec, planetId: local ? planet.id : null };
  }

  function buildUnits(universe, planetIndex, unitId, count = 1, isDefense = false) {
    const Data = getData();
    const planet = universe.planets[planetIndex];
    if (!planet) throw new Error('Pianeta non trovato.');
    normalizePlanet(planet);

    const qty = Math.max(1, Math.floor(Number(count) || 1));
    const unit = isDefense ? Data.DEFENSES[unitId] : Data.SHIPS[unitId];
    if (!unit) throw new Error('Unità sconosciuta.');
    if (!isDefense && unit.specialConstruction === 'bacino') {
      throw new Error(`${unit.name} si costruisce solo nel Bacino Spaziale, non nel Cantiere Navale.`);
    }

    if (!universe.creativeMode) {
      const reqCheck = Data.checkRequirements(unit.requirements, planet, universe, false);
      if (!reqCheck.met) {
        throw new Error(`Requisiti mancanti: ${reqCheck.missing.join(', ')}`);
      }
    }

    const service = !isDefense && window.UniversumServices?.ids.includes(unitId);
    const reservation = service && window.UniversumServices.quote(universe,unitId,qty);
    if (service && (!Number.isSafeInteger(qty) || qty > reservation.free)) throw Error('Limite imperiale delle navi specialistiche raggiunto.');
    if (isDefense && unit.maxCount) {
      const existing = Number(planet.defenses[unitId] || 0);
      const queued = planet.defenseQueue
        .filter((q) => q.id === unitId)
        .reduce((acc, q) => acc + q.remaining, 0);
      if (existing + queued + qty > unit.maxCount) {
        throw new Error(`${unit.name}: massimo ${unit.maxCount} unità consentita per pianeta.`);
      }
    }

    if (universe.creativeMode) {
      if (isDefense) {
        planet.defenses[unitId] = (planet.defenses[unitId] || 0) + qty;
      } else {
        if (service) {
          window.UniversumServices.settlePlanet(universe,planet);
          window.UniversumServices.completed(universe,unitId,qty);
        }
        planet.fleet[unitId] = (planet.fleet[unitId] || 0) + qty;
        if (service) window.UniversumServices.settlePlanet(universe,planet);
      }
      return { instant: true, count: qty };
    }

    const unitCost = Engine.getUnitCostAdjusted(planet, unitId, isDefense);
    const totalCost = reservation?.cost || {
      metal: unitCost.metal * qty,
      crystal: unitCost.crystal * qty,
      deuterium: unitCost.deuterium * qty
    };

    if (!canAfford(planet.resources, totalCost)) {
      throw new Error('Risorse insufficienti per avviare la produzione.');
    }

    deductResources(planet.resources, totalCost);
    const unitDurationSec = Engine.getSingleUnitTime(universe, planet, unitId, isDefense);
    const queue = isDefense ? planet.defenseQueue : planet.shipyardQueue;
    const now = Date.now();
    const startAfter = queue.length > 0 ? queue[queue.length - 1].endTime : now;

    queue.push({
      id: unitId,
      workId: window.UniversumServices?.uid() || 'lot-' + now + '-' + queue.length,
      ...(service ? {baseReservations:reservation.cheap} : {}),
      remaining: qty,
      total: qty,
      unitDurationSec,
      nextUnitEndTime: startAfter + unitDurationSec * 1000,
      endTime: startAfter + unitDurationSec * qty * 1000
    });

    return { instant: false, count: qty, totalDurationSec: unitDurationSec * qty };
  }

  // =========================================================
  // TURBO, CREATIVE CHEATS & RINOMINA CORPI CELESTI
  // =========================================================
  function activateTurbo(universe) {
    const now = Date.now();
    if ((universe.turboUntil || 0) > now) {
      return { active: true, remainingSec: Math.ceil((universe.turboUntil - now) / 1000) };
    }
    universe.turboUntil = now + TURBO_DURATION_MS;
    return { active: true, remainingSec: TURBO_DURATION_MS / 1000 };
  }

  function applyCreativeCheat(universe, planetIndex, actionType) {
    if (!universe.creativeMode) {
      throw new Error('Disponibile solo in Modalità Creativa.');
    }
    const Data = getData();
    const planet = universe.planets[planetIndex] || universe.planets[0];
    normalizePlanet(planet);

    switch (actionType) {
      case 'add-res':
        planet.resources.metal += 10000000;
        planet.resources.crystal += 10000000;
        planet.resources.deuterium += 10000000;
        return '+10.000.000 di ogni risorsa aggiunti!';

      case 'finish-queues':
        if (universe.researchQueue) {
          universe.researches[universe.researchQueue.id] = universe.researchQueue.targetLevel;
          universe.researchQueue = null;
        }
        for (const p of universe.planets) {
          normalizePlanet(p);
          if (p.localResearchQueue) {
            p.localResearches[p.localResearchQueue.id] = p.localResearchQueue.targetLevel;
            p.localResearchQueue = null;
          }
        }
        for (const p of universe.planets) {
          normalizePlanet(p);
          while (p.buildQueue.length > 0) {
            const b = p.buildQueue.shift();
            p.buildings[b.id] = b.targetLevel;
          }
          if (p.moon && Array.isArray(p.moon.buildQueue)) {
            while (p.moon.buildQueue.length > 0) {
              const mb = p.moon.buildQueue.shift();
              p.moon.buildings[mb.id] = mb.targetLevel;
            }
          }
          while (p.shipyardQueue.length > 0) {
            const sq = p.shipyardQueue.shift();
            if (window.UniversumServices?.ids.includes(sq.id)) window.UniversumServices.completed(universe,sq.id,sq.remaining,sq);
            p.fleet[sq.id] = (p.fleet[sq.id] || 0) + sq.remaining;
          }
          while (p.defenseQueue.length > 0) {
            const dq = p.defenseQueue.shift();
            p.defenses[dq.id] = (p.defenses[dq.id] || 0) + dq.remaining;
          }
        }
        return 'Tutte le code di costruzione, ricerca e cantiere completate!';

      case 'unlock-tech':
        Engine.normalizeResearchState(universe);
        for (const rId of Object.keys(Data.RESEARCHES)) {
          const def = Data.RESEARCHES[rId];
          if (def.scope === 'planetary') {
            planet.localResearches[rId] = Math.max(Number(planet.localResearches[rId]) || 0, def.maxLevel || 15);
          } else {
            universe.researches[rId] = Math.max(15, Number(universe.researches[rId] || 0));
          }
        }
        return 'Tutte le tecnologie sbloccate al Livello 15!';

      case 'add-rip':
        planet.fleet.deathStar = (planet.fleet.deathStar || 0) + 10;
        return '+10 Morti Nere schierate in orbita!';

      default:
        throw new Error('Comando creativo non riconosciuto.');
    }
  }

  function renamePlanet(universe, planetIndex, newName) {
    const planet = universe.planets[planetIndex];
    if (!planet) throw new Error('Pianeta non trovato.');
    const cleaned = (newName || '').trim().substring(0, 24);
    if (!cleaned) throw new Error('Il nome del pianeta non può essere vuoto.');

    planet.name = cleaned;
    const key = `${planet.coords.g}:${planet.coords.s}:${planet.coords.p}`;
    if (!universe.galaxyDeltas) universe.galaxyDeltas = {};
    universe.galaxyDeltas[key] = Object.assign({}, universe.galaxyDeltas[key], {
      ownerType: 'player',
      emperor: universe.emperor,
      planetName: cleaned,
      planetId: planet.id
    });
    return cleaned;
  }

  function renameMoon(universe, planetIndex, newName) {
    const planet = universe.planets[planetIndex];
    if (!planet || !planet.moon) throw new Error('Nessuna Luna presente su questo pianeta.');
    const cleaned = (newName || '').trim().substring(0, 24);
    if (!cleaned) throw new Error('Il nome della Luna non può essere vuoto.');

    planet.moon.name = cleaned;
    const key = `${planet.coords.g}:${planet.coords.s}:${planet.coords.p}`;
    if (!universe.galaxyDeltas) universe.galaxyDeltas = {};
    universe.galaxyDeltas[key] = Object.assign({}, universe.galaxyDeltas[key], {
      hasMoon: true,
      moonName: cleaned
    });
    return cleaned;
  }

  // =========================================================
  // AUTOSAVE PERIODICO E SU VISIBILITYCHANGE
  // =========================================================
  let activeUniverseRef = null;
  let autosaveInterval = null;

  function bindAutoSave(getUniverseFn) {
    activeUniverseRef = getUniverseFn;
    if (autosaveInterval) clearInterval(autosaveInterval);

    autosaveInterval = setInterval(() => {
      const uni = typeof activeUniverseRef === 'function' ? activeUniverseRef() : null;
      if (uni && window.UniversumDB) {
        window.UniversumDB.save(uni).catch((e) => console.warn('[Autosave] Errore:', e));
      }
    }, 10000);

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        const uni = typeof activeUniverseRef === 'function' ? activeUniverseRef() : null;
        if (uni && window.UniversumDB) {
          window.UniversumDB.save(uni).catch(() => {});
        }
      }
    });
  }

  Object.assign(Engine, {
    startBuilding,
    startResearch,
    buildUnits,
    activateTurbo,
    applyCreativeCheat,
    renamePlanet,
    renameMoon,
    bindAutoSave
  });
})();
